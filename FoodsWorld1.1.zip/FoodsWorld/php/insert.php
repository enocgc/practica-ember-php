<?php 
$data =json_decode(file_get_contents("php://input"));
$receta= $data->receta;
$ingrediente =$data->ingrediente;
$procedimiento=$data->procedimiento;
$pais=$data->pais;
$numero=$data->numero;

var_dump(Nombre);

$conn=new mysqli("localhost","root","","lab5");

$sql="INSERT INTO comidas (receta,ingrediente,procedimiento,pais,numero) VALUES ('$Nombre','$Apellido'
,'$Telefono','$Email')";

if($conn->query($sql)===TRUE){
	echo "New record created successfully";
}else{
	echo "Error:".$sql."<br>".$conn->error;
}

$conn->close();
echo "You informacion has been successfully added to eh dadta base";

?>